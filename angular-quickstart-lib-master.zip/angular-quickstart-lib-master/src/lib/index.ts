export { LibComponent } from './src/component/lib.component';
export { LibService } from './src/service/lib.service';
export { LibModule } from './src/module';
